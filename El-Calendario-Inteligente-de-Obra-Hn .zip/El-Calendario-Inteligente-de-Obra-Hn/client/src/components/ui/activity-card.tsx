import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown, AlertTriangle, CheckCircle, XCircle, CloudRain, Sun, Cloud, Hammer } from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { WeatherForecast, Suitability } from "@/lib/types";
import { getMonthStats } from "@/lib/weather-utils";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface ActivityCardProps {
  name: string;
  riskLevel: string;
  monthForecast: { date: Date; weather: WeatherForecast; suitability: Suitability }[];
}

export function ActivityCard({ name, riskLevel, monthForecast }: ActivityCardProps) {
  const [isOpen, setIsOpen] = useState(false);
  const stats = getMonthStats(monthForecast);

  const getRiskBadge = (level: string) => {
    switch (level) {
      case "critical": return <Badge variant="destructive" className="bg-red-600 uppercase text-[10px] tracking-wider">Crítico</Badge>;
      case "high": return <Badge variant="destructive" className="bg-orange-500 uppercase text-[10px] tracking-wider">Alto Riesgo</Badge>;
      case "medium": return <Badge className="bg-yellow-500 text-black hover:bg-yellow-400 uppercase text-[10px] tracking-wider">Medio</Badge>;
      default: return <Badge variant="secondary" className="bg-green-100 text-green-800 hover:bg-green-200 uppercase text-[10px] tracking-wider">Bajo</Badge>;
    }
  };

  const getWeatherIcon = (condition: string) => {
    switch (condition) {
      case "stormy": return <CloudRain className="h-3 w-3 text-red-500" />;
      case "rainy": return <CloudRain className="h-3 w-3 text-orange-500" />;
      case "cloudy": return <Cloud className="h-3 w-3 text-blue-400" />;
      case "windy": return <Cloud className="h-3 w-3 text-gray-400" />;
      default: return <Sun className="h-3 w-3 text-yellow-500" />;
    }
  };

  const getStatusColor = (status: string) => {
     switch (status) {
       case "recommended": return "bg-green-500";
       case "acceptable": return "bg-yellow-500";
       case "avoid": return "bg-red-500";
       default: return "bg-gray-300";
     }
  };

  return (
    <Card className="mb-3 border-l-4 border-l-primary shadow-sm hover:shadow-md transition-shadow overflow-hidden">
      <Collapsible open={isOpen} onOpenChange={setIsOpen}>
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-4 flex-1">
            <div className="bg-muted p-2 rounded-sm hidden sm:block">
              <Hammer className="h-5 w-5 text-foreground" />
            </div>
            <div className="grid gap-1 w-full">
              <div className="flex items-center justify-between w-full pr-4">
                 <h3 className="font-semibold text-lg leading-none truncate mr-2">{name}</h3>
                 {getRiskBadge(riskLevel)}
              </div>
              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                <span className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-green-500"></div> {stats.recommended} días óptimos</span>
                <span className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-yellow-500"></div> {stats.acceptable} aceptables</span>
                <span className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-red-500"></div> {stats.avoid} evitar</span>
              </div>
            </div>
          </div>
          
          <CollapsibleTrigger asChild>
            <Button variant="ghost" size="sm" className="w-9 p-0">
              <ChevronDown className={cn("h-4 w-4 transition-transform", isOpen && "rotate-180")} />
              <span className="sr-only">Toggle</span>
            </Button>
          </CollapsibleTrigger>
        </div>

        <CollapsibleContent>
          <div className="px-4 pb-4 pt-0 border-t bg-muted/20">
            
            {/* Calendar Strip Visualization */}
            <div className="mt-4 mb-6">
                <h4 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">Calendario de Viabilidad (Próximos 30 días)</h4>
                <div className="flex w-full h-8 gap-[1px] rounded-md overflow-hidden">
                    <TooltipProvider>
                    {monthForecast.map((day, i) => (
                        <Tooltip key={i}>
                            <TooltipTrigger asChild>
                                <div 
                                  className={cn("flex-1 h-full transition-all hover:opacity-80 cursor-pointer hover:scale-y-110 origin-bottom", getStatusColor(day.suitability.status))}
                                ></div>
                            </TooltipTrigger>
                            <TooltipContent>
                                <div className="text-center">
                                    <p className="font-bold">{format(day.date, "EEEE d MMM", { locale: es })}</p>
                                    <p className="text-xs">{day.suitability.status === 'recommended' ? 'Recomendado' : day.suitability.status === 'acceptable' ? 'Aceptable' : 'Evitar'}</p>
                                    <p className="text-xs opacity-80">{day.weather.description}</p>
                                </div>
                            </TooltipContent>
                        </Tooltip>
                    ))}
                    </TooltipProvider>
                </div>
                <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
                    <span>{format(monthForecast[0].date, "d MMM", { locale: es })}</span>
                    <span>{format(monthForecast[29].date, "d MMM", { locale: es })}</span>
                </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
                {/* Recommended Days List */}
                <div className="space-y-2">
                    <h5 className="text-sm font-bold text-green-700 flex items-center gap-2">
                        <CheckCircle className="h-4 w-4" /> Días Recomendados
                    </h5>
                    <div className="bg-white rounded border p-2 h-32 overflow-y-auto text-sm">
                        {monthForecast.filter(d => d.suitability.status === "recommended").length > 0 ? (
                            <div className="grid grid-cols-2 gap-2">
                                {monthForecast.filter(d => d.suitability.status === "recommended").map((day, i) => (
                                    <div key={i} className="flex items-center gap-2 text-xs">
                                        <span className="font-medium w-12">{format(day.date, "d MMM", { locale: es })}</span>
                                        {getWeatherIcon(day.weather.condition)}
                                    </div>
                                ))}
                            </div>
                        ) : <span className="text-muted-foreground italic">No hay días ideales en este periodo.</span>}
                    </div>
                </div>

                {/* Days to Avoid List */}
                <div className="space-y-2">
                    <h5 className="text-sm font-bold text-red-700 flex items-center gap-2">
                        <XCircle className="h-4 w-4" /> Días a Evitar
                    </h5>
                    <div className="bg-white rounded border p-2 h-32 overflow-y-auto text-sm">
                        {monthForecast.filter(d => d.suitability.status === "avoid").length > 0 ? (
                            <div className="grid grid-cols-1 gap-1">
                                {monthForecast.filter(d => d.suitability.status === "avoid").map((day, i) => (
                                    <div key={i} className="flex items-center justify-between gap-2 text-xs border-b border-dashed last:border-0 pb-1">
                                        <span className="font-medium text-red-900">{format(day.date, "d MMM", { locale: es })}</span>
                                        <span className="text-muted-foreground truncate max-w-[120px]">{day.suitability.reason}</span>
                                    </div>
                                ))}
                            </div>
                        ) : <span className="text-muted-foreground italic">No hay días críticos a evitar.</span>}
                    </div>
                </div>
            </div>
            
            <div className="mt-4 p-3 bg-blue-50 text-blue-900 text-sm rounded border border-blue-100">
                <p className="font-medium flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-blue-500"></div>
                  Recomendación Técnica:
                </p>
                <p className="mt-1 text-blue-800/80 pl-4">
                  {riskLevel === "critical" 
                    ? "Actividad crítica: Solo trabajar en días verdes. Si hay días amarillos, extremar medidas de protección." 
                    : "Actividad flexible: Se puede avanzar en días amarillos si se protegen los materiales."}
                </p>
            </div>
          </div>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
}
