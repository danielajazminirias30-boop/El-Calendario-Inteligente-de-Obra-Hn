import { useState, useMemo } from "react";
import { ACTIVITIES, DEPARTMENTS } from "@/lib/construction-data";
import { getMonthForecast, getSimulatedWeather } from "@/lib/weather-utils";
import { ActivityCard } from "@/components/ui/activity-card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar as CalendarIcon, MapPin, Search, Filter, HardHat, Info } from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";

export default function Home() {
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [selectedDeptId, setSelectedDeptId] = useState<string>("francisco_morazan"); // Default to capital
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");

  const selectedDept = DEPARTMENTS.find(d => d.id === selectedDeptId) || DEPARTMENTS[0];
  const currentWeather = date ? getSimulatedWeather(date, selectedDept) : null;

  const categories = useMemo(() => {
    return ["all", ...Array.from(new Set(ACTIVITIES.map(a => a.category)))];
  }, []);

  const filteredActivities = useMemo(() => {
    const lowerSearch = searchTerm.toLowerCase();
    return ACTIVITIES.filter(act => {
      // Fuzzy-ish search: matches if any part of the name includes the search term
      // Or if the search term is a "close enough" match (simplified here to just substring)
      const matchesSearch = act.name.toLowerCase().includes(lowerSearch) || 
                            act.category.toLowerCase().includes(lowerSearch);
                            
      const matchesCategory = categoryFilter === "all" || act.category === categoryFilter;
      return matchesSearch && matchesCategory;
    });
  }, [searchTerm, categoryFilter]);

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header / Hero */}
      <div className="bg-primary text-primary-foreground py-8 px-4 shadow-lg relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 bg-[url('https://images.unsplash.com/photo-1541888946425-d81bb19240f5?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center mix-blend-overlay pointer-events-none"></div>
        <div className="container mx-auto max-w-5xl relative z-10">
          <div className="flex flex-col justify-between gap-4">
            <div className="flex justify-between items-start">
                <div>
                  <h1 className="text-2xl md:text-4xl font-bold tracking-tight flex items-center gap-3">
                    <HardHat className="h-8 w-8 md:h-10 md:w-10 text-secondary" />
                    Calendario de Obra Honduras
                  </h1>
                  <p className="text-primary-foreground/80 mt-2 max-w-xl text-sm md:text-base">
                    Planificación inteligente de actividades constructivas basada en clima regional y riesgos técnicos.
                  </p>
                </div>
                
                {/* Credit Badge */}
                <div className="bg-white/10 backdrop-blur-sm px-3 py-1 rounded-full text-[10px] md:text-xs border border-white/20 text-white/90 shadow-sm whitespace-nowrap">
                  Realizado por Daniela Irias
                </div>
            </div>
            
            <div className="flex items-center justify-between mt-4 pt-4 border-t border-white/10">
               <div className="text-xs opacity-75">Fecha Actual: {format(new Date(), "PPP", { locale: es })}</div>
            </div>
          </div>
        </div>
      </div>

      <main className="container mx-auto max-w-5xl px-4 -mt-6 relative z-20">
        {/* Controls Card */}
        <Card className="shadow-xl border-t-4 border-t-secondary mb-8">
          <CardHeader className="pb-4">
            <CardTitle className="text-xl flex items-center gap-2">
              <Filter className="h-5 w-5 text-muted-foreground" />
              Configuración del Proyecto
            </CardTitle>
            <CardDescription>
              Ingresa la fecha de inicio y ubicación para obtener recomendaciones del primer mes.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Date Picker */}
              <div className="space-y-2">
                <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                  Fecha de Inicio
                </label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant={"outline"}
                      className={cn(
                        "w-full justify-start text-left font-normal h-12",
                        !date && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {date ? format(date, "PPP", { locale: es }) : <span>Seleccionar fecha</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={setDate}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>

              {/* Region Selector */}
              <div className="space-y-2">
                <label className="text-sm font-medium leading-none">
                  Ubicación / Departamento
                </label>
                <Select value={selectedDeptId} onValueChange={setSelectedDeptId}>
                  <SelectTrigger className="h-12">
                    <SelectValue placeholder="Seleccionar departamento" />
                  </SelectTrigger>
                  <SelectContent>
                    {DEPARTMENTS.map((dept) => (
                      <SelectItem key={dept.id} value={dept.id}>
                        {dept.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Weather Preview */}
              <div className="bg-muted/50 rounded-lg p-3 border flex items-center justify-between">
                {currentWeather ? (
                  <div className="w-full">
                    <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1 font-bold">Clima Inicial Estimado</div>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-2xl font-bold">{currentWeather.temp}°C</div>
                        <div className="text-xs text-muted-foreground capitalize max-w-[120px] leading-tight">{currentWeather.description}</div>
                      </div>
                      <div className="text-right">
                         <div className="text-sm font-medium">Lluvia: {currentWeather.rainChance}%</div>
                         <Badge variant={currentWeather.rainChance > 40 ? "destructive" : "outline"} className="mt-1 text-[10px]">
                           {currentWeather.humidity === "Alta" ? "Humedad Alta" : "Humedad Baja"}
                         </Badge>
                      </div>
                    </div>
                  </div>
                ) : (
                  <span className="text-muted-foreground text-sm">Selecciona una fecha</span>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          
          {/* Sidebar Filters */}
          <div className="lg:col-span-1 space-y-6">
            <div className="sticky top-6">
              <div className="mb-6">
                <label className="text-sm font-medium mb-2 block">Buscar Actividad</label>
                <div className="relative">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input 
                    placeholder="Ej. Techo, Aluzinc..." 
                    className="pl-8" 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Categorías</label>
                <ScrollArea className="h-[400px] pr-4">
                  <div className="space-y-1">
                    {categories.map(cat => (
                      <Button
                        key={cat}
                        variant={categoryFilter === cat ? "secondary" : "ghost"}
                        className="w-full justify-start text-sm font-normal capitalize h-9"
                        onClick={() => setCategoryFilter(cat)}
                      >
                        {cat === "all" ? "Todas" : cat}
                        {categoryFilter === cat && <span className="ml-auto bg-primary/10 text-primary px-1.5 py-0.5 rounded text-xs">{
                          cat === "all" ? ACTIVITIES.length : ACTIVITIES.filter(a => a.category === cat).length
                        }</span>}
                      </Button>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            </div>
          </div>

          {/* Activities List */}
          <div className="lg:col-span-3">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold">Actividades Sugeridas</h2>
              <span className="text-sm text-muted-foreground">
                Mostrando {filteredActivities.length} actividades
              </span>
            </div>

            {date ? (
              <div className="space-y-1">
                {filteredActivities.map((activity) => (
                  <ActivityCard 
                    key={activity.id} 
                    name={activity.name} 
                    riskLevel={activity.riskLevel}
                    monthForecast={getMonthForecast(date, selectedDept, activity)}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-20 border-2 border-dashed rounded-lg">
                <Info className="h-10 w-10 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium">Selecciona una fecha de inicio</h3>
                <p className="text-muted-foreground">Para calcular los mejores días, necesitamos saber cuándo comienza la obra.</p>
              </div>
            )}
          </div>

        </div>
      </main>
    </div>
  );
}
