import { addDays, getMonth, format } from "date-fns";
import { es } from "date-fns/locale";
import { WeatherForecast, Suitability, Activity, Department, Region } from "./types";

// Honduras Seasonality (Simplified)
// Dry Season: Dec - Apr (Months 11, 0, 1, 2, 3)
// Wet Season: May - Nov (Months 4, 5, 6, 7, 8, 9, 10)
// Canicula (Dry spell in rainy season): Late July/Early Aug

export function getSimulatedWeather(date: Date, department: Department): WeatherForecast {
  const month = getMonth(date);
  const isDrySeason = [11, 0, 1, 2, 3].includes(month);
  const isCanicula = month === 6 && date.getDate() > 15; // Late July
  const dayOfMonth = date.getDate();
  
  // Regional variations
  let rainChanceBase = isDrySeason ? 15 : 65;
  if (isCanicula) rainChanceBase = 25;
  
  // North coast rains more in "dry" season (frontal systems)
  if (department.region === "north" || department.region === "insular") {
    if (month >= 9 || month <= 1) rainChanceBase += 25; // Rainiest Oct-Jan
  }

  // South is very dry in dry season
  if (department.region === "south" && isDrySeason) {
    rainChanceBase = 8;
  }

  // Create natural rain patterns: don't have ALL days dry or ALL days rainy
  // Use day of month to create some clustering
  const dayPattern = dayOfMonth % 7; // 0-6 cycle for natural patterns
  let rainModifier = 0;
  
  if (dayPattern === 0 || dayPattern === 1) rainModifier = -10; // Days 7,14,21,28 tend drier
  else if (dayPattern === 3 || dayPattern === 4) rainModifier = +15; // Days 3,10,17,24,31 tend wetter
  
  let finalRainChance = Math.min(100, Math.max(0, rainChanceBase + rainModifier));
  
  let condition: WeatherForecast["condition"] = "sunny";
  if (finalRainChance > 80) condition = "stormy";
  else if (finalRainChance > 50) condition = "rainy";
  else if (finalRainChance > 20) condition = "cloudy";
  
  let temp = 30;
  if (department.region === "central" || department.region === "west") temp = 25; // Cooler highlands
  if (condition === "rainy") temp -= 2;
  if (condition === "stormy") temp -= 4;
  
  // Season adjustments
  if (month === 11 || month === 0) temp -= 3; // Dec/Jan cooler
  if (month === 3 || month === 4) temp += 4; // Apr/May hottest

  return {
    date,
    condition,
    temp: Math.round(temp),
    humidity: finalRainChance > 30 ? "Alta" : "Baja",
    rainChance: Math.round(finalRainChance),
    description: getDescription(condition, temp)
  };
}

function getDescription(condition: string, temp: number): string {
  if (condition === "stormy") return "Tormentas eléctricas probables";
  if (condition === "rainy") return "Lluvias intermitentes";
  if (condition === "cloudy") return "Nublado con amenaza de lluvia";
  if (condition === "windy") return "Vientos fuertes";
  if (temp > 32) return "Soleado y muy caluroso";
  return "Soleado y despejado";
}

export function getActivitySuitability(activity: Activity, weather: WeatherForecast): Suitability {
  // 1. CRITICAL & HIGH RISK: Strict rules
  if (activity.riskLevel === "critical" || activity.riskLevel === "high") {
    if (weather.condition === "stormy") {
      return { score: 0, status: "avoid", reason: "Riesgo crítico por tormenta" };
    }
    if (weather.condition === "rainy" && weather.rainChance > 75) {
       return { score: 15, status: "avoid", reason: "Lluvia intensa impide ejecución" };
    }
    if (weather.condition === "rainy") {
      return { score: 45, status: "acceptable", reason: "Posible con protección estricta" };
    }
    if (weather.condition === "cloudy" && weather.rainChance > 50) {
       return { score: 55, status: "acceptable", reason: "Riesgo moderado de lluvia" };
    }
  }

  // 2. MEDIUM RISK
  if (activity.riskLevel === "medium") {
    if (weather.condition === "stormy") {
       return { score: 25, status: "avoid", reason: "Tormenta eléctrica" };
    }
    if (weather.condition === "rainy" && weather.rainChance > 70) {
       return { score: 55, status: "acceptable", reason: "Proteger zona de trabajo" };
    }
  }

  // 3. SPECIFIC CATEGORY RULES
  
  // Excavation & Earthwork (Mud is the enemy)
  if (activity.category === "Preliminares" || activity.category === "Cimentación") {
    if (weather.rainChance > 70) {
       return { score: 35, status: "avoid", reason: "Riesgo alto de lodo/derrumbes" };
    } else if (weather.rainChance > 40) {
       return { score: 60, status: "acceptable", reason: "Precaución con lodo" };
    }
  }

  // Concrete (Pouring) - CRITICAL
  if (activity.name.toLowerCase().includes("colado") || activity.name.toLowerCase().includes("fundición")) {
     if (weather.rainChance > 60) {
        return { score: 25, status: "avoid", reason: "Riesgo alto para mezcla" };
     }
     if (weather.rainChance > 30) {
        return { score: 65, status: "acceptable", reason: "Tener lonas listas" };
     }
  }
  
  // Painting/Finishes (Humidity)
  if ((activity.category.includes("Acabados") || activity.category === "Mampostería") && (activity.name.toLowerCase().includes("pintura") || activity.name.toLowerCase().includes("impermeabiliz") || activity.name.toLowerCase().includes("repello"))) {
    if (weather.humidity === "Alta" && weather.rainChance > 50) {
       return { score: 50, status: "acceptable", reason: "Humedad moderada - lento secado" };
    } else if (weather.humidity === "Alta" && weather.rainChance > 30) {
       return { score: 70, status: "acceptable", reason: "Usar acelerantes de secado" };
    }
  }

  // Roof work (Safety) - CRITICAL
  if (activity.category === "Techo" || activity.name.toLowerCase().includes("techo") || activity.name.toLowerCase().includes("cubierta")) {
     if (weather.condition === "stormy") {
        return { score: 0, status: "avoid", reason: "Peligro mortal" };
     }
     if (weather.rainChance > 60) {
        return { score: 35, status: "avoid", reason: "Superficie resbalosa" };
     }
     if (weather.rainChance > 30) {
        return { score: 70, status: "acceptable", reason: "Usar arnés y precaución" };
     }
  }

  // If nothing matched above, it's recommended
  return { score: 100, status: "recommended", reason: "Condiciones óptimas" };
}

export function getMonthForecast(startDate: Date, department: Department, activity: Activity): { date: Date, weather: WeatherForecast, suitability: Suitability }[] {
  const results = [];
  let current = startDate;
  
  // Generate 30 days
  for (let i = 0; i < 30; i++) {
    const weather = getSimulatedWeather(current, department);
    const suitability = getActivitySuitability(activity, weather);
    results.push({ date: current, weather, suitability });
    current = addDays(current, 1);
  }
  
  return results;
}

// Helper to get counts for badges
export function getMonthStats(forecast: ReturnType<typeof getMonthForecast>) {
  return {
    recommended: forecast.filter(d => d.suitability.status === "recommended").length,
    acceptable: forecast.filter(d => d.suitability.status === "acceptable").length,
    avoid: forecast.filter(d => d.suitability.status === "avoid").length,
  };
}
