export type Region = "north" | "south" | "central" | "west" | "east" | "insular";
export type ClimateType = "tropical_rainforest" | "tropical_savanna" | "tropical_monsoon" | "subtropical_highland";
export type RiskLevel = "low" | "medium" | "high" | "critical";

export interface Department {
  id: string;
  name: string;
  region: Region;
  climate: ClimateType;
}

export interface Activity {
  id: string;
  name: string;
  category: string;
  riskLevel: RiskLevel;
}

export interface WeatherForecast {
  date: Date;
  condition: "sunny" | "cloudy" | "rainy" | "stormy" | "windy";
  temp: number; // Celsius
  humidity: string;
  rainChance: number; // 0-100
  description: string;
}

export interface Suitability {
  score: number; // 0-100
  status: "recommended" | "acceptable" | "avoid";
  reason: string;
}
